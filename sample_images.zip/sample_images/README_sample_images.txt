README: sample images

These images are intended to test the SegmentCC/CurateCC/PlotCC R image analysis workflow.

They correspond to z-maximum intensity projections of image stacks acquired for iMEFs that have been transfected with MSR-targeting sgRNA and dCas9-GFP-VPR. The cells were fixed 30 hours post-transfection and stained with DAPI as well as subjected to an H3K27ac immunostaining.